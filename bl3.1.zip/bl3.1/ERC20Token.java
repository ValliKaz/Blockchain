import java.util.HashMap;
import java.util.Map;

public class ERC20Token {
    private String name;
    private String symbol;
    private int decimals;
    private Map<String, Integer> balances;

    // Constructor
    public ERC20Token(String name, String symbol, int decimals) {
        this.name = name;
        this.symbol = symbol;
        this.decimals = decimals;
        this.balances = new HashMap<>();
    }

    // Transfer tokens from one address to another
    public void transfer(String from, String to, int amount) {
        int balance = balances.getOrDefault(from, 0);
        if (balance < amount) {
            System.out.println("Insufficient balance");
            return;
        }
        balances.put(from, balance - amount);
        balances.put(to, balances.getOrDefault(to, 0) + amount);
        System.out.println("Transfer successful");
    }

    // Check balance of an address
    public int balanceOf(String address) {
        return balances.getOrDefault(address, 0);
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Getter for symbol
    public String getSymbol() {
        return symbol;
    }

    // Getter for decimals
    public int getDecimals() {
        return decimals;
    }

    // Main method to test the token
    public static void main(String[] args) {
        ERC20Token token = new ERC20Token("MyToken", "MTK", 18);

        token.balances.put("Alice", 1000);
        token.balances.put("Bob", 500);
        token.balances.put("Charlie", 200);

        token.transfer("Alice", "Bob", 200);
        token.transfer("Charlie", "Alice", 100);
        token.transfer("Bob", "Charlie", 50);

        System.out.println("Alice balance: " + token.balanceOf("Alice"));
        System.out.println("Bob balance: " + token.balanceOf("Bob"));
        System.out.println("Charlie balance: " + token.balanceOf("Charlie"));
    }
}